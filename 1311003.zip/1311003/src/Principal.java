/*
import GUI.*;	
import Game.*;

public class Principal  {
	public static void main (String[]args){
		GameController controller=new GameController();
		MainWindow gameWin=new MainWindow();
		StartWindow startWin=new StartWindow();
		
		startWin.addObserver(controller);
		gameWin.addObserver(controller);
		
		gameWin.createGUI();
		startWin.createGUI();
	}
}
*/